let carts=document.querySelectorAll('.btn');
let products=[
{
	name:"Saraswati",
	tag:"murti",
	price:400,
	inCart:0
},

{
	name:"Ganesh",
	tag:"murti",
	price:300,
	inCart:0
},
{
	name:"Lion",
	tag:"murti",
	price:200,
	inCart:0
},
{
	name:"wood item",
	tag:"murti",
	price:500,
	inCart:0
}
];
for(i=0;i<carts.length;i++)
{
	carts[i].addEventListener('click',() =>
	{
		
		cartNumbers(products[i]);
	})
}



function onLoadCartNumbers(){
	var productNumbers=localStorage.getItem('cartNumbers');
	if ( productNumbers )
		{
			
			document.querySelector('.cart span').textContent = productNumbers;
		}
}
		

function cartNumbers(product)
{
	console.log("the product clicked is",product);
	
	let productNumbers = localStorage.getItem('cartNumbers');
		productNumbers=parseInt(productNumbers);
		
		if(productNumbers)
		{
			
			localStorage.setItem('cartNumbers', productNumbers + 1);
			document.querySelector('.cart span').textContent = productNumbers + 1;
		}
		else
		{
			localStorage.setItem('cartNumbers', 1);
			document.querySelector('.cart span').textContent = 1;
		}

}
	onLoadCartNumbers();