<?php
$servername="localhost";
$username="root";
$password="";
$dbname="mcaproject";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if($conn)
{
	echo "connection ok";
}
else
{
	die("connection failed because ".mysqli_connect_error());
}
error_reporting(0);


?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

body {
  background-color: #ffffcc;
  padding: 20px;
  font-family: Comic Sans MS;
}

/* Center website */
.main {
  max-width: 1000px;
  margin: auto;
}

h1 {
  font-size: 50px;
  word-break: break-all;
}

.row {
  margin: 8px -16px;
}

/* Add padding BETWEEN each column */
.row,
.row > .column {
  padding: 8px;
}

/* Create four equal columns that floats next to each other */
.column {
  float: left;
  width: 30%;
}

/* Clear floats after rows */ 


.row:after { 
   content: "."; 
   visibility: hidden; 
   display: block; 
   clear: both;
}


/* Content */
.content {
  background-color: white;
  padding: 10px;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 900px) {
  .column {
    width: 50%;
  }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}

.btn {
  font-size: 20px;
  color: white;
  background:#52c23e;
  border: none;
  border-radius: 5px;
   padding: 5px 5px;
   hovor:green;
   font-family:"Comic Sans MS";

}
.cart{
	background-color:royalblue;
	cursor:pointer;
}
</style>



</head>
<body>
<center>  <button type="button" id="101" class="cart" onclick="">cart!
<span>0</span></button>

<!-- MAIN (Center website) -->
<div class="main">
<center><h1>Wood Craft Item</h1></center>
<hr>


<!-- Portfolio Gallery Grid -->
<div class="row">
  <div class="column">
    <div class="content">
      <img src="wood/sar.jfif" alt="sar" style="width:100%">
     <h4>Saraswati</h4>
	  <p >Rs. 400<p>
	<center>  <button type="button" id="1" formaction="/action_fetch.php"class="btn">Add to cart!</button>
	<button type="button" class="btn" onclick="">Buy now!</button></center>
	   
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="wood/gannu.jpg" alt="Lights" style="width:100%">
      <h4>Ganesh</h4>
	  <p>Rs. 300<p>
	<center>  <button type="button" id="2" formaction="/action_fetch.php" class="btn" onclick="fetch.php">Add to cart!</button>
	<button type="button" class="btn" onclick="">Buy now!</button></center>
	
	
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src= "wood/lion.jpg"  alt="Nature" style="width:100%">
    <h4>Lion</h4>
	  <p>Rs. 200<p>
	<center>  <button type="button" id="3" formaction="/action_fetch.php" class="btn" onclick="fetch.php">Add to cart!</button>
	<button type="button" class="btn" onclick="">Buy now!</button></center>
	 
    </div> <br><br>
  </div><br><br><br><br><br><br><br>
  
  <div class="column">
    <div class="content">
    <img src= "wood/img.jfif" alt="Nature" style="width:100%">
    <h4>wooditem</h4>
	  <p>Rs. 500<p>
	<center>  <button type="button" id="4" class="btn" formaction="/action_fetch.php" onclick="">Add to cart!</button>
	<button type="button" class="btn" onclick="">Buy now!</button></center>
			<script src="main.js"></script>
	
	</body>
	</html>
  


